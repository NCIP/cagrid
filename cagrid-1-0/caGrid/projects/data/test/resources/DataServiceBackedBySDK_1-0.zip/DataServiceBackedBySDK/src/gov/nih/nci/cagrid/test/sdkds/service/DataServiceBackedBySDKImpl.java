package gov.nih.nci.cagrid.test.sdkds.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class DataServiceBackedBySDKImpl extends DataServiceBackedBySDKImplBase {

	
	public DataServiceBackedBySDKImpl() throws RemoteException {
		super();
	}
	
}

