package gov.nih.nci.cagrid.bdt.data.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class DataServiceWithBdtImpl extends DataServiceWithBdtImplBase {

	
	public DataServiceWithBdtImpl() throws RemoteException {
		super();
	}
	


	public gov.nih.nci.cagrid.bdt.stubs.reference.BulkDataHandlerReference bdtQuery(gov.nih.nci.cagrid.cqlquery.CQLQuery cqlQuery) throws RemoteException, gov.nih.nci.cagrid.data.faults.QueryProcessingExceptionType, gov.nih.nci.cagrid.data.faults.MalformedQueryExceptionType {
		org.apache.axis.message.addressing.EndpointReferenceType epr = new org.apache.axis.message.addressing.EndpointReferenceType();
		gov.nih.nci.cagrid.bdt.service.globus.resource.BaseResourceHome bdtHome = null;
		org.globus.wsrf.ResourceKey bdtResourceKey = null;
		org.apache.axis.MessageContext ctx = org.apache.axis.MessageContext.getCurrentContext();
		String servicePath = ctx.getTargetService();
		String bdtHomeName = org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME + servicePath + "/" + "dataServiceWithBdtBulkDataHandlerHome";

		try {
			javax.naming.Context initialContext = new javax.naming.InitialContext();
			bdtHome = (gov.nih.nci.cagrid.bdt.service.globus.resource.BaseResourceHome) initialContext.lookup(bdtHomeName);
			bdtResourceKey = bdtHome.createBDTResource();
			
			//  Grab my newly created resource and set whatever needs to be set on it now
			BDTResource thisResource = (BDTResource)bdtHome.find(bdtResourceKey);
			String classToQnameMapfile = gov.nih.nci.cagrid.data.service.ServiceConfigUtil.getClassToQnameMappingsFile();
			java.io.InputStream wsddStream = new java.io.FileInputStream(gov.nih.nci.cagrid.data.service.ServiceConfigUtil
				.getConfigProperty(gov.nih.nci.cagrid.data.DataServiceConstants.SERVER_CONFIG_LOCATION));
			thisResource.initialize(cqlQuery, classToQnameMapfile, wsddStream);

			//  This is where the creator of this resource type can set whatever needs
			//  to be set on the resource so that it can function appropriatly  for instance
			//  if you want the resouce to only have the query string then there is where you would
			//  give it the query string.
			
			
			
			


			String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
			transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
			transportURL += "DataServiceWithBdtBulkDataHandler";
			epr = org.globus.wsrf.utils.AddressingUtils.createEndpointReference(transportURL,bdtResourceKey);
		} catch (Exception e) {
			throw new RemoteException("Error looking up BDT home:" + e.getMessage(), e);
		}
		
        
		//return the typed EPR
		gov.nih.nci.cagrid.bdt.stubs.reference.BulkDataHandlerReference ref = new gov.nih.nci.cagrid.bdt.stubs.reference.BulkDataHandlerReference();
		ref.setEndpointReference(epr);

		return ref;	}

}

