package gov.nih.nci.cagrid.basic.data.service.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this BasicDataServiceResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class BasicDataServiceResource extends BaseResourceBase {



}
