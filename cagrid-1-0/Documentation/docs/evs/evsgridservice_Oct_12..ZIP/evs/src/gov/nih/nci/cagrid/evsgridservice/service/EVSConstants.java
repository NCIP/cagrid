package gov.nih.nci.cagrid.evsgridservice.service;

/**
 * Created by IntelliJ IDEA.
 * User: shanbhak
 * Date: Sep 25, 2006
 * Time: 4:33:15 PM
 * This class will hold any constants used by <code>EVSGridService</code>
 *
 */


public interface EVSConstants
{
    public final String CACORE_31_URL = "http://cabio.nci.nih.gov/cacore31/http/remoteService";

}
// $Log$

