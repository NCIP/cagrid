*********************************************
DO NOT MODIFY THE CONTENTS OF THIS DIRECTORY.
*********************************************
This directory is used to expand compressed modules jar libraries into.
