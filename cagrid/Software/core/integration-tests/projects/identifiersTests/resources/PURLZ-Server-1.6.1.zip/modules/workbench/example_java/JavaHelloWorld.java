package example_java;

public class JavaHelloWorld
  {

  public static void main(String[] args)
    {
    System.out.println( getMessage());
    }

  public static String getMessage()
    {
    return "Hello World!";
    }

  }
