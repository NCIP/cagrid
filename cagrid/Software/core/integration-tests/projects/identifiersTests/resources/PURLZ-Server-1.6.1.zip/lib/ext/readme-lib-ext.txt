**********************************************************
This directory can be used to host dynamically loaded jars
which will be added to the base classpath when the system
is booted.
**********************************************************

