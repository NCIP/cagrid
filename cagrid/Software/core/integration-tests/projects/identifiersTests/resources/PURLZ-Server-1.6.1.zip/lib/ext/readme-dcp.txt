***********************************************************
Dynamic Compiler Provider Readme
***********************************************************
The DCP requires access to a Javac compiler which is located in
tools.jar which can be found in your JDK lib/ directory.

Please either copy it to this directory or create a symbolic link
to it here. 
