Software libraries distributed with 1060 Net Kernel are licensed under the following
open source licenses.   Any redistribution of these software libraries must include
the appropriate license.

Apache Software Foundation License  [apache.xml]

Xalan, Xerces, XMLSec, Lucene, FOP, Batik

LGPL [LGPL.xml]

XMLVerbatim.xsl

Thai Open Source Software Centre [thaiopensource.xml]

Jing

Mortbay Jetty License  [Jetty-License.html]

Jetty

Kawa Modified GPL [KawaLicense.html]

Kawa, Qexo

W3C Public License [W3C-copyright-software-20021231.html]

HTML Tidy, JTidy

MX4J Apache License [mx4j.xml]

MX4J

Sun XACML Public License [sunxacml.xml]

XACML

Gnu General Public License [GPL.xml]

Streamsicle, Fluid


Our thanks to all those who contributed to these software libraries.