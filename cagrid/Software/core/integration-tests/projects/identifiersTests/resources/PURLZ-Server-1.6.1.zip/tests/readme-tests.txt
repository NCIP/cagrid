***********************************************************
Use this directory for dynamically installable test modules
***********************************************************
Expanded modules located in this directory can be dynamically installed
and removed from the system using the Unit Test tools.  Drop your unit tests
here for system QA testing.

*Remember* Modules must be expanded (not jarred) to be discoverable.
