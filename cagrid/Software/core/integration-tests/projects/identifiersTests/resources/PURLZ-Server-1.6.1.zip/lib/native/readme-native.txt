Jar files placed in this directory will be loaded into the classpath just above 
the JVM and prior to the kernel and dynamic module classloaders.  Libraries which
use JNI native calls should be placed here.

Examples include Berkley DB.