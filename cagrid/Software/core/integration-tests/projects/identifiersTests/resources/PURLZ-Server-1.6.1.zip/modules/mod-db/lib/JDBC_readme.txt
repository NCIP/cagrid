Place your JDBC driver jar in this directory to be automatically picked up by the classloader.
Configure the driver class in the /etc/ConfigRDBMS.xml file of your module.