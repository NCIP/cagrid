package org.cagrid.data.with.sdk41.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServceWithSdk41Impl extends DataServceWithSdk41ImplBase {

	
	public DataServceWithSdk41Impl() throws RemoteException {
		super();
	}
	
}

