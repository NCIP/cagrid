package org.cagrid.test.data.basic15.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.5
 */
public interface BasicDataServiceConstants extends BasicDataServiceConstantsBase {
	
}
