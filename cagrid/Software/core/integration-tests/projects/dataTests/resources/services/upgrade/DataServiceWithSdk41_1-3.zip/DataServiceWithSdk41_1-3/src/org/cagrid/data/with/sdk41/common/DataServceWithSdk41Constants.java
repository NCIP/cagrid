package org.cagrid.data.with.sdk41.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.3
 */
public interface DataServceWithSdk41Constants extends DataServceWithSdk41ConstantsBase {
	
}
