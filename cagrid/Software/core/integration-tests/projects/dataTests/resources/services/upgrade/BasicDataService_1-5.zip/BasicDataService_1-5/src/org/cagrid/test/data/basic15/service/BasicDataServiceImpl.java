package org.cagrid.test.data.basic15.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.5
 * 
 */
public class BasicDataServiceImpl extends BasicDataServiceImplBase {

	
	public BasicDataServiceImpl() throws RemoteException {
		super();
	}
	
}

