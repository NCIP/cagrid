package org.cagrid.data.with.sdk41.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this DataServceWithSdk41Resource type.
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServceWithSdk41Resource extends DataServceWithSdk41ResourceBase {

}
