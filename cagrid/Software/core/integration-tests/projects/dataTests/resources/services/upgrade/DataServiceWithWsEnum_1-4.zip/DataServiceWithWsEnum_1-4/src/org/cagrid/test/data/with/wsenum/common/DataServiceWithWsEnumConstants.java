package org.cagrid.test.data.with.wsenum.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.4
 */
public interface DataServiceWithWsEnumConstants extends DataServiceWithWsEnumConstantsBase {
	
}
