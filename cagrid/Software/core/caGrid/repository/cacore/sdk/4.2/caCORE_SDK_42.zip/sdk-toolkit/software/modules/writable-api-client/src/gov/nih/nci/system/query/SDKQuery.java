package gov.nih.nci.system.query;

import java.io.Serializable;

public interface SDKQuery extends Serializable
{
	
}