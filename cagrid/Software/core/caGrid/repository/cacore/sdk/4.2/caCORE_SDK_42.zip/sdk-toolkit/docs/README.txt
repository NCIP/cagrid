The SDK now supports both code generation and automated deployment.

To build and deploy the SDK 'example' project:
*  Open /example-project/build directory;
*  Modify the code generation (codegen.properties) and deployment (install.properties) property files as desired for your environment
*  Open the build.xml file and execute the 'deploy:local:install' target