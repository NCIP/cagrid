package gov.nih.nci.system.query.hql;

import java.io.Serializable;

public interface HQLManipulationQuery extends Serializable
{
	
}