package gov.nih.nci.codegen.transformer.jet;

import gov.nih.nci.codegen.transformer.UMLModelJETTransformer;
import gov.nih.nci.codegen.Artifact;
import gov.nih.nci.codegen.artifact.BaseArtifact;
import gov.nih.nci.codegen.util.TransformerUtils;
import gov.nih.nci.codegen.GenerationException;

import gov.nih.nci.ncicb.xmiinout.domain.UMLModel;
import gov.nih.nci.ncicb.xmiinout.domain.UMLClass;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociation;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAssociationEnd;
import gov.nih.nci.ncicb.xmiinout.domain.UMLAttribute;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class EHCacheTransformer extends UMLModelJETTransformer{

	  protected final String NL = System.getProperties().getProperty("line.separator");
  protected final String TEXT_1 = "  " + NL + "<ehcache>" + NL + "" + NL + "\t<diskStore path=\"";
  protected final String TEXT_2 = "\"/>" + NL + "" + NL + "\t<defaultCache" + NL + "\t\tmaxElementsInMemory=\"500\"" + NL + "\t\teternal=\"false\"" + NL + "\t\ttimeToIdleSeconds=\"1800\"" + NL + "\t\ttimeToLiveSeconds=\"100000\"" + NL + "\t\toverflowToDisk=\"true\"/>" + NL + "\t";
  protected final String TEXT_3 = "\t" + NL + "\t<cache name=\"";
  protected final String TEXT_4 = "\"" + NL + "\t\tmaxElementsInMemory=\"500\"" + NL + "\t\teternal=\"false\"" + NL + "\t\ttimeToIdleSeconds=\"1800\"" + NL + "\t\ttimeToLiveSeconds=\"100000\"" + NL + "\t\toverflowToDisk=\"true\"/>" + NL + "\t";
  protected final String TEXT_5 = NL + "\t<cache name=\"";
  protected final String TEXT_6 = ".";
  protected final String TEXT_7 = "\"" + NL + "\t\tmaxElementsInMemory=\"500\"" + NL + "\t\teternal=\"false\"" + NL + "\t\ttimeToIdleSeconds=\"1800\"" + NL + "\t\ttimeToLiveSeconds=\"100000\"" + NL + "\t\toverflowToDisk=\"true\"/>" + NL + "\t\t\t";
  protected final String TEXT_8 = NL + "</ehcache>";

public Artifact executeTemplate(UMLModel model, Map<String, Object> configurationParams) throws GenerationException{
		BaseArtifact artifact = new BaseArtifact(transformerUtils);
		artifact.setContent(generate(model, configurationParams));
		return artifact;
	}
	
	public String generate(UMLModel model, Map configurationParams) throws GenerationException
  {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    stringBuffer.append((String)configurationParams.get("CACHE_PATH"));
    stringBuffer.append(TEXT_2);
    for(UMLClass klass:transformerUtils.getAllClasses(model)){
    stringBuffer.append(TEXT_3);
    stringBuffer.append(transformerUtils.getFQCN(klass));
    stringBuffer.append(TEXT_4);
    for(UMLAssociation assoc:klass.getAssociations()){
		List<UMLAssociationEnd> assocEnds = assoc.getAssociationEnds();
		UMLAssociationEnd otherEnd = transformerUtils.getOtherEnd(klass,assocEnds);

		if(otherEnd.isNavigable())
		{
			if(transformerUtils.isAssociationEndMany(otherEnd))
			{
    stringBuffer.append(TEXT_5);
    stringBuffer.append(transformerUtils.getFQCN(klass));
    stringBuffer.append(TEXT_6);
    stringBuffer.append(otherEnd.getRoleName());
    stringBuffer.append(TEXT_7);
    }
		}	
	}
    }
    stringBuffer.append(TEXT_8);
    return stringBuffer.toString();
  }
}