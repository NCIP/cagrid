package org.globus.rsl;


public class RslEvaluationException extends Exception {

    public RslEvaluationException(String msg) {
	super(msg);
    }

}
