package org.test.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class IntroduceTestServiceImpl extends IntroduceTestServiceImplBase {

	
	public IntroduceTestServiceImpl() throws RemoteException {
		super();
	}
	

	public java.lang.String newMethod(java.lang.String foo) throws RemoteException {
		return foo + " testing";
	}

}

