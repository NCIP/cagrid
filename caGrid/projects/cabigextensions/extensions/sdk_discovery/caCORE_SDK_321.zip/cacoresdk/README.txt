				README
				
This is the root folder of caCORE SDK. This directory contains the following
directories and files.
conf 			- Configuration files for toolkit,system,code generator, templates, license etc.,
lib  			- All required libraries
models 			- caCORESDKTemplate.eap and SDKTestModel.EAP (Enterprise Architect Project files - need Enterprise
         		  Architect Software to open) and corresponding cabioExampleDomainModel.xmi/sdk-test.xmi files.
src   			- Generic Source files for infrastructure and Artifact generation.
build.properties        -
build.xml 		- Main Ant build xml file.
build-custom.properties - Control file to turn on and off ant tasks.
build-custom.xml        -