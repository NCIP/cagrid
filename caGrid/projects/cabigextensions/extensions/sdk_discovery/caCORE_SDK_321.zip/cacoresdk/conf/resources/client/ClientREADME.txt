				README
This is a client package that includes the following.

conf - Contains log4j properties
lib - Contains client.jar which contains domain and framework classes.
      All the included libraries are needed to run the client successfuly.
log - Client log.
