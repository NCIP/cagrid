package org.test2.service.globus.resource;

import javax.xml.namespace.QName;


public interface ResourceConstants {
	public static final String SERVICE_NS = "http://test2.org/IntroduceTestInnerService";
	public static final QName RESOURCE_KEY = new QName(SERVICE_NS, "IntroduceTestServiceInnerServiceKey");
	public static final QName RESOURCE_PROPERY_SET = new QName(SERVICE_NS, "IntroduceTestServiceInnerServiceResourceProperties");

	//Service level metadata (exposed as resouce properties)
	
}
