package gov.nih.nci.cagrid.graph.geometry;

public class Index 
{
	public int index = 0;
	public float value = 0;

}
