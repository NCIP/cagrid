package gov.nih.nci.cagrid.graph.domainmodelapplication;

import gov.nih.nci.cagrid.graph.vstheme.ToolBarButton;

import javax.swing.JComponent;

public class ExpandCollapseButton extends ToolBarButton 
{
	public ExpandCollapseButton(JComponent parent)
	{
		super(parent);
	}
}
