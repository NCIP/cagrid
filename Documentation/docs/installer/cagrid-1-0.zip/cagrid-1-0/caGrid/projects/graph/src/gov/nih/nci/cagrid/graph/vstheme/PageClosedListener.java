package gov.nih.nci.cagrid.graph.vstheme;

import javax.swing.JComponent;

public class PageClosedListener {

	public void pageClosed(InvertedMDIPanel source, JComponent closed, int pagesLeft)
	{
		
	}
}
