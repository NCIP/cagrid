package gov.nih.nci.cagrid.graph.uml;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class UMLDiagramListener
{
     UMLDiagram diagram ;

     public UMLDiagramListener(UMLDiagram d)
     {
    	 this.diagram = d;
     }

     public void classClicked(UMLClass c, MouseEvent e)
     {

     }

     public void associationClicked(UMLClassAssociation c, MouseEvent e)
     {

     }
     
     public void backgroundClicked(MouseEvent e)	
     {
    	 
    	 
     }
     
     public void classKeyPressed(UMLClass c, KeyEvent e)
     {
    	 
     }
     
     public void associationKeyPressed(UMLClassAssociation a, KeyEvent e)
     {
    	 
     }
     
     

}
