package gov.nih.nci.cagrid.graph.uml;

import javax.swing.JPanel;

class UMLMenuBar extends JPanel
{
     public UMLMenuBar()
     {

     }
}
