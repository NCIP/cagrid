package gov.nih.nci.cagrid.graph.domainmodelapplication;

import javax.swing.JPanel;

public class DomainModelXMLOutlineToolBar extends JPanel
{
	
	public DomainModelXMLOutlineToolBar()
	{
		super();
	
	}
}
