To build the required beans, type 'ant jarStubs' at the project's top level.

Due to the data service introduce extension's dependency on the caDSR component, this project now requires Java 1.5 to build.