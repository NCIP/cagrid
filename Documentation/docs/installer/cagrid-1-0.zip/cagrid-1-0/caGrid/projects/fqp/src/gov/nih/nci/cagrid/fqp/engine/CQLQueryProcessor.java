package gov.nih.nci.cagrid.fqp.engine;

import gov.nih.nci.cagrid.cqlresultset.CQLQueryResults;
import gov.nih.nci.cagrid.fqp.exception.FQPException;

/**
 * Created by IntelliJ IDEA.
 * User: kherm
 * Date: May 4, 2006
 * Time: 4:38:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class CQLQueryProcessor implements QueryProcessor{


    public CQLQueryProcessor(Object gsh) {
    }

    /**
     * Executes a CQL
     * @param cql
     * @return
     * @throws FQPException
     */
    public CQLQueryResults execute(Object cql) throws FQPException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

}
