WS-I Sample Application 1.0 package
This package contains an implementation of the WS-I Sample Application 1.0.

Provider:	Apache Software Foundation
Date:		04 December 2003
Version:	0.1
Status:		TBD 

Directory Structure (based on WS-I Sample Application packaging guide)

source/
       java/
             generated/ - generated Java source codes by overriden WSDLs
             implemented/ - implementations of services and clients
       schema/ - schemas used in abstract WSDLs
       wsdl/ - fully overriden WSDLs
             partial/ - abstract WSDLs brought by WS-I
build/ - ant build script
distribution/ - distribution files
              classes/ - compiled Java classes
docs/ - documentation
result/ - test results
                     
At last, please read status.txt and help us making this sample better.

Thanks.

Ias


