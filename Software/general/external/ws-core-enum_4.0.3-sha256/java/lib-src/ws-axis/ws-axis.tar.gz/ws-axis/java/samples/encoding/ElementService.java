package samples.encoding;

import org.w3c.dom.Element;

public class ElementService {
    public Element echoElement(String str, Element elem) {
        return( elem );
    }
}
