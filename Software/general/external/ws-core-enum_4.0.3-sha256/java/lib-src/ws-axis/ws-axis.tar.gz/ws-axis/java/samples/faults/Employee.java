/**
 * Employee.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package samples.faults;

public class Employee {
    private java.lang.String employeeID;
    private java.lang.String employeeName;

    public Employee() {
    }

    public java.lang.String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(java.lang.String employeeID) {
        this.employeeID = employeeID;
    }

    public java.lang.String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(java.lang.String employeeName) {
        this.employeeName = employeeName;
    }
}
