#!/bin/sh
# this assumes webserver is running on port 8080
java samples.attachments.EchoAttachment $*
