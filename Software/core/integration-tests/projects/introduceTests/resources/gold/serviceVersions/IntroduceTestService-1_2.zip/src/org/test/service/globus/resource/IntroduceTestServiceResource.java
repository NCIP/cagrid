package org.test.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this IntroduceTestServiceResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class IntroduceTestServiceResource extends IntroduceTestServiceResourceBase {

}
