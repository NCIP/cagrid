package org.test.context2.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class IntroduceTestServiceContext2Impl extends IntroduceTestServiceContext2ImplBase {

	
	public IntroduceTestServiceContext2Impl() throws RemoteException {
		super();
	}
	
}

