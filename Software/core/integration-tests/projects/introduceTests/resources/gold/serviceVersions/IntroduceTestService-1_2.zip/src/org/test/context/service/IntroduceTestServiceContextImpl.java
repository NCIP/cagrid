package org.test.context.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class IntroduceTestServiceContextImpl extends IntroduceTestServiceContextImplBase {

	
	public IntroduceTestServiceContextImpl() throws RemoteException {
		super();
	}
	
}

