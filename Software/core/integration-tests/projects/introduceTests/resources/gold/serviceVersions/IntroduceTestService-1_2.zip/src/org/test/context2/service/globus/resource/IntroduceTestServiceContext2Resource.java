package org.test.context2.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this IntroduceTestServiceContext2Resource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class IntroduceTestServiceContext2Resource extends IntroduceTestServiceContext2ResourceBase {

}
