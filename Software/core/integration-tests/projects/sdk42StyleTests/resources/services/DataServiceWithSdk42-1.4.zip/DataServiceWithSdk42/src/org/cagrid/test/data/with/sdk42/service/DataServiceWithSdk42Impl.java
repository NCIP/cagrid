package org.cagrid.test.data.with.sdk42.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class DataServiceWithSdk42Impl extends DataServiceWithSdk42ImplBase {

	
	public DataServiceWithSdk42Impl() throws RemoteException {
		super();
	}
	
}

