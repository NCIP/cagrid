package org.cagrid.test.examplesdk2.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this ExampleSdkService2Resource type.
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class ExampleSdkService2Resource extends ExampleSdkService2ResourceBase {

}
