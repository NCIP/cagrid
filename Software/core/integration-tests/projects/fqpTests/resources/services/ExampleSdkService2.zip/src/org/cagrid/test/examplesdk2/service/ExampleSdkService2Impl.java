package org.cagrid.test.examplesdk2.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class ExampleSdkService2Impl extends ExampleSdkService2ImplBase {

	
	public ExampleSdkService2Impl() throws RemoteException {
		super();
	}
	
}

