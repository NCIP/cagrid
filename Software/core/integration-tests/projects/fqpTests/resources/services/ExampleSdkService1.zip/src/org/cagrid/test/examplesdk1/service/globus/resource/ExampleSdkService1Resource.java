package org.cagrid.test.examplesdk1.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this ExampleSdkService1Resource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class ExampleSdkService1Resource extends ExampleSdkService1ResourceBase {

}
