package org.cagrid.test.examplesdk2.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.4
 */
public interface ExampleSdkService1Constants extends ExampleSdkService1ConstantsBase {
	
}
