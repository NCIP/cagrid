package org.cagrid.data.with.sdk42.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.3
 */
public interface DataServiceWithSdk42Constants extends DataServiceWithSdk42ConstantsBase {
	
}
