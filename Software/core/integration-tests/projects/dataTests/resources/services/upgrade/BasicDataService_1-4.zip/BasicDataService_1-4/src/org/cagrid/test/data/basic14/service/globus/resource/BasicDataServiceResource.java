package org.cagrid.test.data.basic14.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this BasicDataServiceResource type.
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class BasicDataServiceResource extends BasicDataServiceResourceBase {

}
