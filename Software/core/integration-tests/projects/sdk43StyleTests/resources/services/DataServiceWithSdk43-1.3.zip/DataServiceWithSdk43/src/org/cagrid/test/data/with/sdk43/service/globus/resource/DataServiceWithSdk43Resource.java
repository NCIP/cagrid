package org.cagrid.test.data.with.sdk43.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this DataServiceWithSdk43Resource type.
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithSdk43Resource extends DataServiceWithSdk43ResourceBase {

}
