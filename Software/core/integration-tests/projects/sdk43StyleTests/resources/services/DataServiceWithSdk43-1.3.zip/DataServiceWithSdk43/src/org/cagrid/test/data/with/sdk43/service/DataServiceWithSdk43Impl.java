package org.cagrid.test.data.with.sdk43.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithSdk43Impl extends DataServiceWithSdk43ImplBase {

	
	public DataServiceWithSdk43Impl() throws RemoteException {
		super();
	}
	
}

