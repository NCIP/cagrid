package org.cagrid.test.data.with.sdj43.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this HelloWorldResource type.
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class HelloWorldResource extends HelloWorldResourceBase {

}
