package org.cagrid.test.data.with.sdj43.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.4
 */
public interface HelloWorldConstants extends HelloWorldConstantsBase {
	
}
