package org.cagrid.test.data.with.sdj43.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.4
 * 
 */
public class HelloWorldImpl extends HelloWorldImplBase {

	
	public HelloWorldImpl() throws RemoteException {
		super();
	}
	
}

