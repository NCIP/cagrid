package org.cagrid.test.data.with.sdk40.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.3
 */
public interface DataServiceWithSdk40Constants extends DataServiceWithSdk40ConstantsBase {
	
}
