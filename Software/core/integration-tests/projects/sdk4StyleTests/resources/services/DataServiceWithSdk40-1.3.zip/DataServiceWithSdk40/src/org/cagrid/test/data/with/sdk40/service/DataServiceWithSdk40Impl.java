package org.cagrid.test.data.with.sdk40.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithSdk40Impl extends DataServiceWithSdk40ImplBase {

	
	public DataServiceWithSdk40Impl() throws RemoteException {
		super();
	}
	
}

