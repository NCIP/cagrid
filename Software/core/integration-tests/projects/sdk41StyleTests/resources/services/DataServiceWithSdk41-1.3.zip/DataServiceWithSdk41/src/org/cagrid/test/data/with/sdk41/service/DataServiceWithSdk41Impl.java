package org.cagrid.test.data.with.sdk41.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class DataServiceWithSdk41Impl extends DataServiceWithSdk41ImplBase {

	
	public DataServiceWithSdk41Impl() throws RemoteException {
		super();
	}
	
}

