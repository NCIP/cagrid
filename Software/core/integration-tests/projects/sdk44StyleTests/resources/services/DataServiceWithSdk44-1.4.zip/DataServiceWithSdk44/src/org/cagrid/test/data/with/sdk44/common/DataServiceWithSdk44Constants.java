package org.cagrid.test.data.with.sdk44.common;

import javax.xml.namespace.QName;


/**
 * Constants class that extends the introduce managed constants.  Developers can add constants to this file.
 *
 * @created by Introduce Toolkit version 1.4
 */
public interface DataServiceWithSdk44Constants extends DataServiceWithSdk44ConstantsBase {
	
}
